JARVIS Android project — APK builder

This ZIP is the Android source project with a GitHub Actions workflow added. It is NOT itself an APK.

To build using GitHub from your phone:
1. Create a new GitHub repository and upload the CONTENTS of this ZIP.
2. Open the repository's Actions tab.
3. Select “Build JARVIS APK” and tap “Run workflow” (or wait for the push build).
4. Open the completed workflow run, find Artifacts, and download “JARVIS-debug-APK”.
5. Extract the downloaded artifact ZIP to get app-debug.apk.
6. Install it on your Android phone. Android may ask you to allow installation from the browser/files app you used. Only install builds you created and trust.

Important: the app calls the Cloudflare Worker URL configured in MainActivity.kt. Confirm that the Worker URL is live and its GEMINI_API_KEY secret is configured. The API key must stay in Cloudflare secrets, never in this Android project or public repository.

This produces a debug APK for testing, not a Play Store release.
