package com.example.jarvis.ui.theme
import androidx.compose.ui.graphics.Color
val DarkBackground = Color(0xFF0D0D0D)
val MessageBubbleDark = Color(0xFF1E1E1E)
val CyanJarvis = Color(0xFF00E5FF)
